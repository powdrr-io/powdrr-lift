FROM public.ecr.aws/x8v8d7g8/mars-base:latest
WORKDIR /app

# Git time-travel: clone, then make the repo's default branch point AT the base
# commit with no future history — a real branch checkout (not a detached HEAD),
# future commits/tags gc'd away so the reference solution can't leak from history.
ARG BASE_SHA=f07c89f8f065010a36b4263eded209b2b1d37063
RUN git clone https://github.com/graphql-python/gql . \
 && DEFAULT="$(git remote show origin | sed -n 's/.*HEAD branch: //p')" \
 && git checkout -B "$DEFAULT" "$BASE_SHA" \
 && git remote remove origin \
 && for b in $(git for-each-ref --format='%(refname:short)' refs/heads | grep -vx "$DEFAULT"); do git branch -D "$b" || true; done \
 && for t in $(git tag); do git merge-base --is-ancestor "$t" HEAD 2>/dev/null || git tag -d "$t"; done \
 && git reflog expire --expire=now --all \
 && git gc --prune=now \
 && (git submodule update --init --recursive || true)

RUN pip install graphql-core==3.3.0a7 && pip install -e ".[test]"

# Dep-drift pin: aiohttp 3.14 removed streams.AsyncStreamReaderMixin, which the
# pinned vcrpy==7.0.0 aiohttp stubs need (8 vcr-backed transport tests error at
# setup otherwise). 3.13.x matches the originally validated environment.
RUN pip install "aiohttp<3.14"

# v1.1 node-id scoring: pytest emits JUnit XML natively via --junitxml; no extra
# reporter package needed.

# Disable git commit hooks (husky etc.): dev-workflow tooling, not task content.
# Broken hook environments otherwise block the agent's (and oracle's) commits.
RUN cd /app && git config core.hooksPath /dev/null

CMD ["/bin/bash"]
